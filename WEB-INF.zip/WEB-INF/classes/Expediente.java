

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.hc.client5.http.cookie.BasicCookieStore;
import org.apache.hc.client5.http.cookie.Cookie;
import org.apache.hc.client5.http.fluent.Executor;
import org.apache.hc.client5.http.fluent.Request;

/**
 * Servlet implementation class Expediente
 */
public class Expediente extends HttpServlet {
    private static final long serialVersionUID = 1L;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public Expediente() {
        super();
        // TODO Auto-generated constructor stub
    }

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // TODO Auto-generated method stub
        //response.getWriter().append("Served at: ").append(request.getContextPath());
        String titulo = "<!DOCTYPE html>" + 
                "<html lang=\"es-es\">" + 
                "<head>" + 
                "<meta charset=\"UTF-8\">" + 
                "<script src=\"https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js\" integrity=\"sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p\" crossorigin=\"anonymous\"></script>" +
                "<link href=\"https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css\" rel=\"stylesheet\" integrity=\"sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3\" crossorigin=\"anonymous\">" +
                "<title>Expediente</title>" +
                "<script src=\"https://code.jquery.com/jquery-3.6.0.min.js\"></script>" +
                "</head>";
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println(titulo);

        String dni = request.getParameter("dni");
        String nombre_alumno = request.getParameter("nombre");
        String apellido_alumno = request.getParameter("apellido");


        out.println("<body><div class='row'> <h1> Expediente de " + apellido_alumno + ", " + nombre_alumno + " (" + dni + ")</h1></div>");
        out.println("<div class='row'><div class='col-4'><img id='fotodni' src='./img.png' alt='foto alumno'/></div>");
        out.println("<div class='col-7'><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum</p>");
        out.println("</div></div>");

        HttpSession session = request.getSession();
        @SuppressWarnings("unchecked")
        List<Cookie> cookie_list = (List<Cookie>) session.getAttribute("cookie");
        Executor executor = Executor.newInstance();
        BasicCookieStore cookies = new BasicCookieStore();
        cookies.addCookie(cookie_list.get(0));
        String url = request.getLocalName();
        String key = session.getAttribute("key").toString();

        String asignaturas = executor.use(cookies)
                .execute(Request.get("http://" + url + ":9090/CentroEducativo/alumnos/" + dni + "/asignaturas/?key=" + key))
                .returnContent().toString();

        JSONArray asignaturas_array = new JSONArray(asignaturas);
        out.println("<h2>Prueba 1</h2>");
        for (int i = 0; i < asignaturas_array.length(); i++) {
            out.println("<h2>Prueba 2</h2>");
            JSONObject asignatura_json = asignaturas_array.getJSONObject(i);
            String acronimo = asignatura_json.getString("asignatura");
            String nota = asignatura_json.getString("nota");
            if(nota.length() == 0) {nota = "Sin calificar";}
            String detallesAsignaturas = executor.use(cookies)
                    .execute(Request.get("http://" + url + ":9090/CentroEducativo/asignaturas/" + acronimo + "/?key=" + key))
                    .returnContent().toString();
            JSONObject detalles = new JSONObject(detallesAsignaturas);
            String nombre = detalles.getString("nombre");
            out.println("<h2>Prueba 3</h2>");
            out.println("<div><p> Expediente: </p> <tr>" + 
                    "<td>" + acronimo + "</td>" + 
                    "<td>" + nombre + "</td>" + 
                    "<td>" + nota + "</td></tr></div>");
        }
        out.println("<script>"
                + "   $(document).ready(function() {\n"
                + "       $.getJSON(\"Foto?dni=" + dni + "\")\r\n"
                + "           .done(function(response) {\r\n"
                + "               $(\"#fotodni\").attr(\"src\", \"data:image/png;base64,\"+response.img);\r\n"
                + "            })\r\n"
                + "           .fail(function(jqxhr, textStatus, error ) {\r\n"
                + "               var err = jqxhr.response.replace(\",\", \"\\n\"); // Peque�os ajustes\r\n"
                + "               alert(\"Algo mal: \"+error);\r\n"
                + "           });"
                + "   });\n"
                + "</script>");
        out.println("</body></html>");
    }

    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // TODO Auto-generated method stub
        doGet(request, response);
    }

}
